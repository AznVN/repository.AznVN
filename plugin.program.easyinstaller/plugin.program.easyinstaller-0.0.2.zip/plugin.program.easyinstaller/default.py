#!/usr/bin/python
#coding=utf-8

from sqlite3 import dbapi2 as db_lib
import xml.etree.ElementTree as ET
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import urllib, urllib2, sys, re, os, shutil, zipfile

KodiVersion = int(xbmc.getInfoLabel("System.BuildVersion")[:2])
plugin_handle = int(sys.argv[1])

Addon_ID = xbmcaddon.Addon().getAddonInfo('id')
mysettings = xbmcaddon.Addon(Addon_ID)
Addon_Name = mysettings.getAddonInfo('name')
Addon_Version = mysettings.getAddonInfo('version')
Addon_Author = mysettings.getAddonInfo('author')
profile = xbmc.translatePath(mysettings.getAddonInfo('profile').decode('utf-8'))
home = xbmc.translatePath(mysettings.getAddonInfo('path').decode('utf-8'))
icon = os.path.join(home, 'icon.png')
fanart = os.path.join(home, 'fanart.jpg')
iconfolder = os.path.join(home, 'resources', 'icons')
datafolder = os.path.join(home, 'resources', 'datafile')
tempfolder = os.path.join(home, 'resources', 'temp')
data_list = os.path.join(home, 'resources', 'datalist')
addon_list = os.path.join(data_list, 'addonlist.xml')
main_menu = os.path.join(data_list, 'mainmenu.xml')
sub_menu = os.path.join(data_list, 'submenu.xml')
special_menu = os.path.join(data_list, 'special.xml')
vip_fshare = os.path.join(data_list, 'fsharevip.xml')
add_source = os.path.join(data_list, 'addsources.xml')

addonfolder = xbmc.translatePath(os.path.join('special://home', 'addons'))
sources_xml = xbmc.translatePath(os.path.join('special://profile', 'sources.xml'))

settings_xml = os.path.join(profile, 'settings.xml')
autoexec_py = xbmc.translatePath("special://profile/autoexec.py")

popupTitle = 'Easy Installer'
menu_regex = "<title>(.+?)</title><link>(.+?)</link><mode>(.+?)</mode><thumbnail>(.+?)</thumbnail>"
RegExp = "<title>%s</title><link>(.*?)</link><RegEx>(.*?)</RegEx><repo_id>(.*?)</repo_id><repo_name>(.*?)</repo_name><addon_id>(.*?)</addon_id><addon_name>(.*?)</addon_name>"

dialog = xbmcgui.Dialog

for unwanted_file in os.listdir(tempfolder):
	file_path = os.path.join(tempfolder, unwanted_file)
	try:
		if os.path.isfile(file_path):
			os.unlink(file_path)
		elif os.path.isdir(file_path): 
			shutil.rmtree(file_path)
	except:
		pass

def make_request(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
	response = urllib2.urlopen(req)
	link = response.read()
	response.close()
	return link

def read_file(file):
	with open(file, 'r') as f:
		content = f.read()
	return content

def main():
	content = read_file(main_menu)
	content = ''.join(content.splitlines()).replace('\t', '')
	match = re.compile(menu_regex).findall(content)
	for title, link, mode, thumb in match:
		if any(x in link for x in ['instaddrep', 'fsharevip', 'sources', 'bonuses']):
			addDir(title, link, mode, ico(thumb), True)
		else:
			addDir(title, link, mode, ico(thumb), False)

def install_addons():
	content = read_file(sub_menu)
	content = ''.join(content.splitlines()).replace('\t', '')
	match = re.compile(menu_regex).findall(content)
	for title, link, mode, thumb in match:
		addDir(title, link, mode, ico(thumb), False)

def bonus():
	content = read_file(special_menu)
	content = ''.join(content.splitlines()).replace('\t', '')
	match = re.compile(menu_regex).findall(content)
	for title, link, mode, thumb in match:
		addDir(title, link, mode, ico(thumb), False)

def ico(s):
	return '%s/%s.png' % (iconfolder, s)

def clear_acctInfo():
	mysettings.setSetting(id = 'vipfshare_username', value = '')
	mysettings.setSetting(id = 'vipfshare_password', value = '')

def set_enable(newaddon, data=None):
	if KodiVersion > 16:
		setit = 1
		if data is None: data = ''
		sql = 'REPLACE INTO installed (addonID,enabled) VALUES(?,?)'
		db_path = xbmc.translatePath(os.path.join('special://profile', 'Database', 'Addons27.db'))
		conn = db_lib.connect(db_path)
		conn.execute(sql, (newaddon, setit,))
		conn.commit()
	else:
		pass

def setall_enable():
	if KodiVersion > 16:
		d = dialog().yesno(popupTitle, 'Bạn có muốn enable các add-ons và repositories không?')
		if d:
			try:
				contents = os.listdir(addonfolder)
				db_path = xbmc.translatePath(os.path.join('special://profile', 'Database', 'Addons27.db'))
				conn = db_lib.connect(db_path)
				conn.executemany('update installed set enabled=1 WHERE addonID = (?)', ((val,) for val in contents))
				conn.commit()
				xbmc.sleep(1000)
				dialog().ok(popupTitle, '[COLOR yellow]Cần phải khởi động lại Kodi[/COLOR] để hoàn thành việc enable các add-ons và repositories. Chúc bạn thưởng thức vui vẻ!')
				xbmc.executebuiltin("XBMC.ActivateWindow(ShutdownMenu)")
			except:
				d_error()
		else:
			good_bye()
			sys.exit(0)
	else:
		dialog().ok(popupTitle, 'Bạn đang dùng phiên bản nhỏ hơn Kodi 17 (Krypton), không cần dùng đến mục này.')

def update_addon_repo():
	xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
	xbmc.executebuiltin('XBMC.UpdateAddonRepos()')

def get_addon(url):
	content = read_file(addon_list)
	content = ''.join(content.splitlines()).replace('\t', '')
	match = re.compile(RegExp%url).findall(content)
	for item1, item2, item3, item4, item5, item6 in match:
		repo_id = item3
		repo_name = item4
		addon_id = item5
		addon_name = item6
	if os.path.isdir(os.path.join(addonfolder, 'plugin.video.%s'%url)) or os.path.isdir(os.path.join(addonfolder, url)):
		d = dialog().yesno(popupTitle, 'Máy [COLOR cyan][B]đã có[/B][/COLOR] add-on %s rồi.'%addon_name, 'Bạn có muốn [COLOR yellow][B]cập nhật nữa[/B][/COLOR] không?')
		if d:
			if url == 'tvvn':
				dialog().ok(popupTitle, '[COLOR magenta][B]Màn hình kế tiếp[/B][/COLOR], vui lòng [COLOR cyan][B]tìm và nhấn vào[/B][/COLOR] [B]%s[/B] [COLOR cyan][B]nằm gần cuối danh sách[/B][/COLOR], rồi nhấn vô [COLOR cyan][B]Cập nhật/Update[/B][/COLOR] để cập nhật lên phiên bản mới nhất.'%addon_name, '[COLOR red][B]Lưu ý[/B][/COLOR][COLOR yellow][B] tên của repo chính chủ là[/B][/COLOR] %s'%repo_name)
				xbmc.executebuiltin('ActivateWindow(10040,addons://%s/xbmc.addon.video)'%repo_id)
			else:
				get_repo(url)
				dialog().ok(popupTitle, '[COLOR magenta][B]Màn hình kế tiếp[/B][/COLOR], vui lòng nhấn vào %s, rồi nhấn vô [COLOR cyan][B]Cập nhật/Update[/B][/COLOR] để cập nhật lên phiên bản mới nhất.'%addon_name, '[COLOR red][B]Lưu ý[/B][/COLOR][COLOR yellow][B] tên của repo chính chủ là[/B][/COLOR] %s'%repo_name)
				if url == "service.subtitles.xshare":
					xbmc.executebuiltin('ActivateWindow(10040,addons://%s/xbmc.subtitle.module)'%repo_id)
				else:
					xbmc.executebuiltin('ActivateWindow(10040,addons://%s/xbmc.addon.video)'%repo_id)
		else:
			good_bye()
			sys.exit(0)
	else:
		d = dialog().yesno(popupTitle, 'Bạn có muốn cài %s không?'%addon_name)
		if d:
			if url == 'tvvn':
				xbmc.executebuiltin("ActivateWindow(10025,plugin://%s)"%addon_id)
			else:
				get_repo(url)
				if url == "service.subtitles.xshare" or url == "thongld.vnplaylist" or url == "kodi4vn.launcher":
					dialog().ok(popupTitle, '[COLOR magenta][B]Màn hình kế tiếp[/B][/COLOR], vui lòng nhấn vào %s, rồi nhấn vô [COLOR cyan][B]Cài/Install[/B][/COLOR] để cài phiên bản mới nhất.'%addon_name, '[COLOR red][B]Lưu ý[/B][/COLOR][COLOR yellow][B] tên của repo chính chủ là[/B][/COLOR] %s'%repo_name)
					if url == "service.subtitles.xshare":
						xbmc.executebuiltin('ActivateWindow(10040,addons://%s/xbmc.subtitle.module)'%repo_id)
					else:
						xbmc.executebuiltin('ActivateWindow(10040,addons://%s/xbmc.addon.video)'%repo_id)
				else:
					xbmc.executebuiltin("ActivateWindow(10025,plugin://%s)"%addon_id)
		else:
			good_bye()
			sys.exit(0)

def get_repo(url):
	content = read_file(addon_list)
	content = ''.join(content.splitlines()).replace('\t', '')
	match = re.compile(RegExp%url).findall(content)
	for item1, item2, item3, item4, item5, item6 in match:
		url = item1
		reg_ex = item2
		repo_id = item3
	content = make_request(url)
	content = ''.join(content.splitlines()).replace('\t', '')
	match = re.compile(reg_ex).findall(content)
	lastest_version = match[0]
	if url.startswith('https://raw.github.com/hieuhienvn/') or url.startswith('https://raw.github.com/thanhnguyenphu/'):
		url = os.path.join(url.replace("addons.xml", "zips/"), repo_id)
	else:
		url = os.path.join(url.replace("addons.xml", ""), repo_id)
	src = '%s/%s-%s.zip'%(url, repo_id, lastest_version)
	dst = os.path.join(tempfolder, '%s-%s.zip')%(repo_id, lastest_version)
	dp = xbmcgui.DialogProgress()
	dp.create(popupTitle, 'Downloading and extracting zip file... Please wait...', '[COLOR magenta]Đang tải và giải nén zip file... Vui lòng chờ...[/COLOR]')
	urllib.urlretrieve(src, dst)
	un_zip_it = zipfile.ZipFile(dst, 'r')
	un_zip_it.extractall(addonfolder)
	un_zip_it.close()
	dp.close()
	xbmc.sleep(1000)
	set_enable(repo_id, data=None)
	xbmc.sleep(1000)
	update_addon_repo()
	xbmc.sleep(1000)
	os.remove(dst)

def favorite_repo():
	keyb = xbmc.Keyboard('', 'Nhập link trực tiếp tải về repo')
	keyb.doModal()
	if (keyb.isConfirmed()):
		src = keyb.getText()
		if len(src) > 0:
			try:
				repo_zip = (urllib2.urlopen(src).geturl()).split('/')[-1]
				dst = os.path.join(tempfolder, repo_zip)
				dp = xbmcgui.DialogProgress()
				dp.create(popupTitle, 'Downloading and extracting zip file... Please wait...', '[COLOR magenta]Đang tải và giải nén zip file... Vui lòng chờ...[/COLOR]')
				f = urllib2.urlopen(src)
				with open(dst, "wb") as newrepo:
					newrepo.write(f.read())
				un_zip_it = zipfile.ZipFile(dst, 'r')
				un_zip_it.extractall(addonfolder)
				un_zip_it.close()
				dp.close()
				xbmc.sleep(1000)
				repo_id = repo_zip.split('-')[0]
				set_enable(repo_id, data=None)
				xbmc.sleep(1000)
				update_addon_repo()
				xbmc.sleep(1000)
				os.remove(dst)
				dialog().ok(popupTitle, 'Đã cài thành công [COLOR lime]%s[/COLOR]'%repo_id)
			except:
				dialog().ok(popupTitle, '[COLOR magenta]Có lỗi xảy ra.[/COLOR] Vui lòng kiểm tra lại đường dẫn tải về repository hoặc thử lại sau.')
		else:
			dialog().ok(popupTitle, 'Bạn chưa nhập đường dẫn để tải về repository.')
	else:
		good_bye()

def down_zip():
	keyb = xbmc.Keyboard('', 'Nhập link trực tiếp tải về zip file')
	keyb.doModal()
	if (keyb.isConfirmed()):
		src = keyb.getText()
		if len(src) > 0:
			try:
				file_zip = (urllib2.urlopen(src).geturl()).split('/')[-1]
				dst = os.path.join(datafolder, file_zip)
				dp = xbmcgui.DialogProgress()
				dp.create(popupTitle, 'Downloading zip file... Please wait...', '[COLOR magenta]Đang tải zip file... Vui lòng chờ...[/COLOR]')
				f = urllib2.urlopen(src)
				with open(dst, "wb") as newzipfile:
					newzipfile.write(f.read())
				dp.close()
				dialog().ok(popupTitle, 'Đã tải xong zip file')
			except:
				dialog().ok(popupTitle, '[COLOR magenta]Có lỗi xảy ra.[/COLOR] Vui lòng kiểm tra lại đường dẫn tải về zip file hoặc thử lại sau.')
		else:
			dialog().ok(popupTitle, 'Bạn chưa nhập đường dẫn để tải về zip file.')
	else:
		good_bye()

def del_zip():
	d = dialog().yesno(popupTitle, 'Bạn có muốn xoá zip file trong add-on này không?')
	if d:
		try:
			for unwanted_file in os.listdir(datafolder):
				file_path = os.path.join(datafolder, unwanted_file)
				if os.path.isfile(file_path):
					os.unlink(file_path)
				elif os.path.isdir(file_path): 
					shutil.rmtree(file_path)
			dialog().ok(popupTitle, 'Đã xoá xong zip file.')
		except:
			d_error()
	else:
		good_bye()

def d_error():
	dialog().ok(popupTitle, '[COLOR orangered]Có lỗi xảy ra... Vui lòng thử lại sau...[/COLOR]')

def good_bye():
	dialog().ok(popupTitle, 'Chào tạm biệt. Chúc bạn luôn vui vẻ!')

def d_ok(url):
	dialog().ok(popupTitle, 'Máy không có [COLOR yellow]%s[/COLOR]'%url, 'Cần phải cài add-on này mới nhập được VIP Fshare.')

def dlg_ok(url):
	dialog().ok(popupTitle, 'Đã nhập[COLOR cyan][B] VIP Fshare[/B][/COLOR] thành công cho [COLOR yellow][B]%s[/B][/COLOR]'%url)

def fshare_vip():
	content = read_file(vip_fshare)
	content = ''.join(content.splitlines()).replace('\t', '')
	match = re.compile(menu_regex).findall(content)
	for title, link, mode, thumb in match:
		addDir(title, link, mode, ico(thumb), False)

def fshare_vietmediaf(url):
	if os.path.isdir(os.path.join(addonfolder, 'plugin.video.vietmediaF')):
		mysettings.openSettings()
		username = mysettings.getSetting('vipfshare_username')
		password = mysettings.getSetting('vipfshare_password')
		if len(username) > 0 and len(password) > 0:
			xbmcaddon.Addon('plugin.video.vietmediaF').setSetting(id = 'fshare_option', value = 'true')
			xbmcaddon.Addon('plugin.video.vietmediaF').setSetting(id = 'fshare_username', value = username)
			xbmcaddon.Addon('plugin.video.vietmediaF').setSetting(id = 'fshare_password', value = password)
			dlg_ok(url)
		else:
			d = dialog().yesno(popupTitle, 'Password hoặc username hoặc cả 2 đều còn trống.', 'Nhấn [COLOR cyan]Yes/Có[/COLOR] để nhập lại.', 'Nhấn [COLOR magenta]No/Không[/COLOR] để thoát ra.')
			if d:
				fshare_vietmediaf(url)
			else:
				good_bye()
				sys.exit(0)
	else:
		d_ok(url)
		sys.exit(0)

def fshare_xshare(url):
	if os.path.isdir(os.path.join(addonfolder, 'plugin.video.xshare')):
		mysettings.openSettings()
		username = mysettings.getSetting('vipfshare_username')
		password = mysettings.getSetting('vipfshare_password')
		if len(username) > 0 and len(password) > 0:
			xbmcaddon.Addon('plugin.video.xshare').setSetting(id = 'getLinkFree', value = 'false')
			xbmcaddon.Addon('plugin.video.xshare').setSetting(id = 'usernamef', value = username)
			xbmcaddon.Addon('plugin.video.xshare').setSetting(id = 'passwordf', value = password)
			dlg_ok(url)
		else:
			d = dialog().yesno(popupTitle, 'Password hoặc username hoặc cả 2 đều còn trống.', 'Nhấn [COLOR cyan]Yes/Có[/COLOR] để nhập lại.', 'Nhấn [COLOR magenta]No/Không[/COLOR] để thoát ra.')
			if d:
				fshare_xshare(url)
			else:
				good_bye()
				sys.exit(0)
	else:
		d_ok(url)
		sys.exit(0)

def fshare_xshareTiny(url):
	if os.path.isdir(os.path.join(addonfolder, 'plugin.video.xshare.tiny')):
		mysettings.openSettings()
		username = mysettings.getSetting('vipfshare_username')
		password = mysettings.getSetting('vipfshare_password')
		if len(username) > 0 and len(password) > 0:
			xbmcaddon.Addon('plugin.video.xshare.tiny').setSetting(id = 'useFshareAccShared', value = 'false')
			xbmcaddon.Addon('plugin.video.xshare.tiny').setSetting(id = 'fshareUser', value = username)
			xbmcaddon.Addon('plugin.video.xshare.tiny').setSetting(id = 'fsharePasswd', value = password)
			dlg_ok(url)
		else:
			d = dialog().yesno(popupTitle, 'Password hoặc username hoặc cả 2 đều còn trống.', 'Nhấn [COLOR cyan]Yes/Có[/COLOR] để nhập lại.', 'Nhấn [COLOR magenta]No/Không[/COLOR] để thoát ra.')
			if d:
				fshare_xshareTiny(url)
			else:
				good_bye()
				sys.exit(0)
	else:
		d_ok(url)
		sys.exit(0)

def del_fshare():
	if os.path.exists(settings_xml):
		username = mysettings.getSetting(id = 'vipfshare_username')
		password = mysettings.getSetting(id = 'vipfshare_password')
		if username == "" and password == "":
			dialog().ok(popupTitle, '[COLOR yellow]Không có[/COLOR] thông tin về tài khoản VIP Fshare trong add-on này.')
		elif len(username) > 0 or len(password) > 0:
			d = dialog().yesno(popupTitle, 'Bạn có muốn [COLOR yellow]xoá VIP Fshare[/COLOR] không?', '[COLOR red]Lưu ý[/COLOR] mục này [COLOR cyan]chỉ xoá tài khoản Fshare nằm trong add-on này[/COLOR] mà thôi.')
			if d:
				clear_acctInfo()
				dialog().ok(popupTitle, '[COLOR magenta]Đã xoá[/COLOR] thông tin VIP Fshare trong add-on này.')
			else:
				good_bye()
	else:
			dialog().ok(popupTitle, '[COLOR yellow]Không có[/COLOR] thông tin về tài khoản VIP Fshare trong add-on này.')
	sys.exit(0)

def auto_exec():
	if os.path.isfile(autoexec_py):
		d = dialog().yesno(popupTitle, 'Máy đã có autoexec.py rồi.', 'Có muốn [COLOR yellow]tạo autoexec.py mới không?[/COLOR]')
		if d:
			auto_execWork()
		else:
			good_bye()
			sys.exit(0)
	else:
		auto_execWork()

def auto_execWork():
	if os.path.isfile(settings_xml):
		mysettings.setSetting(id='SelectAddon', value='')
	mysettings.openSettings()
	with open(settings_xml) as f:
		content = f.read()
		match = re.compile('<setting id="SelectAddon" value="(.+?)" />').findall(content)
		if len(match) == 1:
			for item in match:
				ChosenAddon = item
				if 'script' in ChosenAddon:
					dialog().ok(popupTitle, 'Đây là [COLOR red]script add-on[/COLOR] và [COLOR red]không thể autostart[/COLOR] được. Vui lòng chọn add-on khác.')
					sys.exit(0)
				else:
					if os.path.isfile(autoexec_py):
						os.remove(autoexec_py)
					f = open(autoexec_py, "w+")
					f.write('import xbmc\nxbmc.executebuiltin("RunAddon(%s)")'%ChosenAddon)
					f.close()
					dialog().ok(popupTitle, 'Đã tạo autoexec.py thành công. Cần phải [COLOR cyan][B]khởi động lại Kodi[/B][/COLOR] để hoàn thành công việc. Chúc bạn thưởng thức vui vẻ!')
					xbmc.executebuiltin("XBMC.ActivateWindow(ShutdownMenu)")
		else:
			dialog().ok(popupTitle, 'Vui lòng chọn 1 add-on.')
			sys.exit(0)

def del_exec():
	if os.path.isfile(autoexec_py):
		d = dialog().yesno(popupTitle, 'Bạn có muốn xoá autoexec.py không?')
		if d:
			os.remove(autoexec_py)
			mysettings.setSetting(id='SelectAddon', value='')
			dialog().ok(popupTitle, 'Đã xoá autoexec.py thành công', 'Chúc bạn thưởng thức vui vẻ!')
		else:
			good_bye()
			sys.exit(0)
	else:
		dialog().ok(popupTitle, 'Máy này không có autoexec.py')
		sys.exit(0)

def change_skin():
	xbmc.executebuiltin('Addon.Default.Set(xbmc.gui.skin)')

def manual_update():
	d = dialog().yesno(popupTitle, 'Bạn có muốn cập nhật các add-ons và repositories ngay bây giờ không?')
	if d:
		update_addon_repo()
		dialog().ok(popupTitle, 'Đang tiến hành cập nhật, mời tiếp tục dùng Kodi.', 'Chúc bạn thưởng thức vui vẻ!')
	else:
		good_bye()
		sys.exit(0)

def open_settings():
	mysettings.openSettings()
	sys.exit(0)

def add_sources():
	content = read_file(add_source)
	content = ''.join(content.splitlines()).replace('\t', '')
	match = re.compile(menu_regex).findall(content)
	for title, link, mode, thumb in match:
		addDir(title, link, mode, ico(thumb), False)

def indent(elem, level=0):
	i = "\n" + level*"    "
	if len(elem):
		if not elem.text or not elem.text.strip():
			elem.text = i + "    "
		if not elem.tail or not elem.tail.strip():
			elem.tail = i
		for elem in elem:
			indent(elem, level+1)
		if not elem.tail or not elem.tail.strip():
			elem.tail = i
	else:
		if level and (not elem.tail or not elem.tail.strip()):
			elem.tail = i

def checkTree(url):
	if os.path.exists(sources_xml):
		content = read_file(sources_xml)
		if url in content:
			dialog().ok(popupTitle, 'Máy đã có nguồn [COLOR lime]%s[/COLOR] rồi.'%url)
			sys.exit(0)
		else:
			check_tree(url)
	else:
		check_tree(url)

def check_tree(url):
	d = dialog().yesno(popupTitle, 'Bạn có muốn [COLOR lime]nhập nguồn[/COLOR] [COLOR yellow]%s[/COLOR] vào Kodi không?'%url)
	if d:
		if os.path.isfile(sources_xml):
			appendTree(url)
		else:
			buildTree(url)
			xbmc.sleep(1000)
			appendTree(url)
	else:
		good_bye()
		sys.exit(0)

def buildTree(url):
	sources = ET.Element("sources")
	programs = ET.SubElement(sources, "programs")
	default = ET.SubElement(programs, "default", pathversion="1")
	video = ET.SubElement(sources, "video")
	default = ET.SubElement(video, "default", pathversion="1")
	music = ET.SubElement(sources, "music")
	default = ET.SubElement(music, "default", pathversion="1")
	pictures = ET.SubElement(sources, "pictures")
	default = ET.SubElement(pictures, "default", pathversion="1")
	files = ET.SubElement(sources, "files")
	default = ET.SubElement(files, "default", pathversion="1")
	indent(sources)
	tree = ET.ElementTree(sources)
	tree.write(sources_xml)
	writeTree()

def appendTree(url):
	tree = ET.parse(sources_xml)
	root = tree.getroot()
	if url == "http://repo.kodi.vn":
		source_name = ".kodi.vn"
	elif url == "http://srp.nu":
		source_name = ".superRepo"
	elif url == "http://fusion.tvaddons.co":
		source_name = ".fusion"
	new = ET.Element("source")
	newsub1 = ET.SubElement(new, "name").text=source_name
	newsub2 = ET.SubElement(new, "path", pathversion="1").text=url
	newsub3 = ET.SubElement(new, "allowsharing").text="true"
	root[4].append(new)
	indent(root)
	with open(sources_xml, 'w') as f:
		f.write(ET.tostring(root))
	xbmc.sleep(1000)
	writeTree()
	dialog().ok(popupTitle, 'Đã nhập thành công [COLOR lime][B]%s[/B][/COLOR] và tên của nguồn là [COLOR yellow][B]%s[/B][/COLOR]'%(url, source_name), 'Cần phải [COLOR cyan][B]khởi động lại Kodi[/B][/COLOR] mới thấy được nguồn mới nhập.')

def writeTree():
	content = read_file(sources_xml)
	content = content.replace('<default pathversion="1" />', '<default pathversion="1"></default>')
	with open(sources_xml, 'w') as f:
		f.write(content)

def addDir(name, url, mode, iconimage, isFolder = False):
	u = (sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage))
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	if iconimage == fanart:
		liz.setProperty('fanart_image', fanart)
	else:
		liz.setProperty('fanart_image', iconimage)
	ok = xbmcplugin.addDirectoryItem(plugin_handle, url = u, listitem = liz, isFolder = isFolder)
	return ok

def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param

params = get_params()

url = None
name = None
mode = None
iconimage = None

try:
	if os.path.isdir(os.path.join(addonfolder, 'repository.aznvn')):
		pass
	else:
		url = 'https://raw.github.com/AznVN/repository.aznvn/master/addons.xml'
		content = make_request(url)
		content = ''.join(content.splitlines()).replace('\t', '')
		match = re.compile('id="repository.aznvn" name=".+?" version="(.+?)"').findall(content)
		lastest_version = match[0]
		src = '%s%s/%s-%s.zip'%(url.replace('addons.xml', ''), url.split("/")[4], url.split("/")[-3], lastest_version)
		dst = os.path.join(tempfolder, '%s-%s.zip')%(url.split("/")[4], lastest_version)
		urllib.urlretrieve(src, dst)
		xbmc.executebuiltin("XBMC.Extract(%s, %s)"%(dst, addonfolder))
		xbmc.sleep(1000)
		set_enable('repository.aznvn', data=None)
		xbmc.sleep(1000)
		update_addon_repo()
		xbmc.sleep(1000)
		os.remove(dst)
except:
	pass

try: url = urllib.unquote_plus(params["url"])
except: pass
try: name = urllib.unquote_plus(params["name"])
except: pass
try: mode = int(params["mode"])
except: pass
try: iconimage = urllib.unquote_plus(params["iconimage"])
except: pass

if mode == None or url == None or len(url) < 1:
	clear_acctInfo()
	main()

elif mode == 1:
	install_addons()

elif mode == 2:
	fshare_vietmediaf(url)

elif mode == 3:
	fshare_xshare(url)

elif mode == 4:
	fshare_xshareTiny(url)

elif mode == 5:
	checkTree(url)

elif mode == 6:
	change_skin()

elif mode == 7:
	auto_exec()

elif mode == 8:
	del_exec()

elif mode == 9:
	del_fshare()

elif mode == 10:
	open_settings()

elif mode == 11:
	favorite_repo()

elif mode == 12:
	fshare_vip()

elif mode == 13:
	add_sources()

elif mode == 14:
	manual_update()

elif mode == 15:
	down_zip()

elif mode == 16:
	del_zip()

elif mode == 17:
	setall_enable()

elif mode == 18:
	bonus()

elif mode == 21:
	get_addon(url)

xbmcplugin.endOfDirectory(plugin_handle)